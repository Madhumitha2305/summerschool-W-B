import 'dart:io';

void main() {
  List<String> names = [];
  List<int> rollNumbers = [];

  for (var i = 0; i < 5; i++) {
    stdout.write('Enter name ${i + 1}: ');
    String name = stdin.readLineSync()!;
    names.add(name);

    stdout.write('Enter roll number ${i + 1}: ');
    int rollNumber = int.parse(stdin.readLineSync()!);
    rollNumbers.add(rollNumber);
  }

  List<String> combinedList = [];
  for (var i = 0; i < names.length; i++) {
    if (i % 2 == 0) {
      combinedList.add('${names[i]} - ${rollNumbers[i]}');
    }
  }

  print('Combined list with even indices:');
  print(combinedList);
}
