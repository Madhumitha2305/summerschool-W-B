package com.example.summerschoolsession11

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
